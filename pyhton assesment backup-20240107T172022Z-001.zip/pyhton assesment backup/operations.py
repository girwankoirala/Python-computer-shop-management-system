from datetime import datetime
from read import *
from write import *

def buyoperate(d):
        laptop_sold = []
        more_products = True

        name = input("Dear customer!!, Please Enter your name: ")
        print("\n")

        while more_products== True:
            print("--------------------------------------------------------------------------------------------------------------------------------------------------------------")
            print("ID      \t Name     \t Brand    \t Price    \t Quantity  \t Processor \t Graphic Card      ")
            print("--------------------------------------------------------------------------------------------------------------------------------------------------------------")


            table()

            print("--------------------------------------------------------------------------------------------------------------------------------------------------------------" )
        
            print("\n")

            s = False
            while s == False:
                try:
                    purchase_ID = int(input("Enter the ID of laptop you want to purchase: "))
                    
                

                # Valid ID
                    while purchase_ID <= 0 or purchase_ID > len(d):
                        print("Please provide valid laptop ID!")
                        print("\n")

                        try:
                            purchase_ID = int(input("Enter the ID of laptop you want to purchase: "))
                        except:
                            print("Invalid!!please enter Valid option")


                    print("Dear customer,please provide us your details: ")

                    s = True
                
                except:
                    print("Invalid!! Please enter valid input. ")
            #print("-----------------------------------------------------------------------------------")
            print("\n")
            

            
            phone_number = input("Dear customer!! Please Enter your Contact/phone number: ")
            print("\n")

            
            print("\n")


            s = False
            while s == False:
                try:
                    CustomerQuantity = int(input("Enter the quantity of laptop you want to purchase: "))
                    
                        
                    print("\n")
                    # Valid Quantity

                    DesiredQuantity = d[purchase_ID][3]
                    while CustomerQuantity <= 0 or CustomerQuantity > int(DesiredQuantity):
                        print("Dear user, the quantity you've asked for is not available right now.")
                        print("\n")
                        DesiredQuantity = int(input("Dear customer!! Please enter the quantity of the laptops you want to purchase: "))
                    

                

                    print("\n")

                        #
                    d[purchase_ID][3] = int(d[purchase_ID][3]) - int(CustomerQuantity)

                    file = open("girwan.txt", "w")

                    for values in d.values():
                            file.write(str(values[0])+ "," +str(values[1])+ "," +str(values[2])+ "," +str(values[3])+ "," +str(values[4]+ "," +str(values[5])))
                            file.write("\n")
                    file.close()
                    
                    s= True
                except:
                    print("Invalid!!Please enter the valid input")  

            #
            ProductName = d[purchase_ID][0]
            SelectedQuantity = CustomerQuantity
            UnitPrice = d[purchase_ID][2]
            Selected_Quantity_Price = d[purchase_ID][2].replace("$", '')
            Total_Price = int(Selected_Quantity_Price) * int(SelectedQuantity)
            Graphics_card = d[purchase_ID][5]

            laptop_sold.append([ProductName, SelectedQuantity, UnitPrice, Total_Price, Graphics_card])

            customer_request = input("Do you want to add another laptop to your list?? Continue (Y/N)?").upper()
            print("\n")
        
            if customer_request == "Y":
                more_products = True
            else:
                total = 0
                shipping_charge = 30
                
                for i in laptop_sold:
                    total += int(i[3])
                grand_total = total + shipping_charge

                dateandtime = datetime.now()
                x = str(dateandtime).split(" ")
                s = "_".join(x)
                y = s.replace(":","_")

                printbuy(name, phone_number, dateandtime, laptop_sold, total, shipping_charge, grand_total)


                
                billbuy(name,y,phone_number,dateandtime,laptop_sold,total,shipping_charge, grand_total)


def selloperate(d):
        laptop_sold = []
        more_products = True

        while more_products== True:
            print("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------")
            print("S.N      \t Product name     \t  Brand \t \t Price \t\t  Quantity  \t\t Processor \t\t Graphics Card")
            print("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------")


            file = open("girwan.txt", "r")
            a = 1
            for line in file:
                print(a, "\t\t" + line.replace(",", "\t\t"))
                a = a + 1
            print("----------------------------------------------------------------------------------------------------------------------------------" )
            file.close()
            print("\n")

            purchase_ID = int(input("Enter the Valid ID of laptop you want to purchase: "))
            print("\n")

            # Valid ID
            while purchase_ID <= 0 or purchase_ID > len(d):
                print("Please provide valid laptop ID!")
                print("\n")

                purchase_ID = int(input("Enter the Valid ID of laptop you want to purchase: \n"))

            print("Dear Customer!! please provide the necessary details: ")
            #print("--------------------------------------------------------------------------------------------------------------------------------------")
            print("\n")
            
            name = "Girwan's Laptop Shop"
            print("\n")
            
            phone_number = 9863443122
            print("\n")

            
            print("\n")

            CustomerQuantity = int(input("Enter the quantity of laptop you want to purchase: "))
            print("\n")
            # Valid Quantity

            DesiredQuantity = d[purchase_ID][3]
            while CustomerQuantity <= 0 or CustomerQuantity > int(DesiredQuantity):
                print("Dear Customer, the quantity is not available right now.")
                print("\n")
                DesiredQuantity = int(input("Enter the quantity of the laptops you want to purchase: "))
            print("\n")

                #
            d[purchase_ID][3] = int(d[purchase_ID][3]) + int(CustomerQuantity)

            file = open("girwan.txt", "w")

            for values in d.values():
                    file.write(str(values[0])+ "," +str(values[1])+ "," +str(values[2])+ "," +str(values[3])+ "," +str(values[4])+ "," +str(values[5]))
                    file.write("\n")
            file.close()

            #
            ProductName = d[purchase_ID][0]
            SelectedQuantity = CustomerQuantity
            UnitPrice = d[purchase_ID][2]
            Selected_Quantity_Price = d[purchase_ID][2].replace("$", '')
            Total_Price = int(Selected_Quantity_Price) * int(SelectedQuantity)
            Graphics_card = d[purchase_ID][5]

            laptop_sold.append([ProductName, SelectedQuantity, UnitPrice, Total_Price, Graphics_card])

            customer_request = input("Do you want to Take another laptop(Y/N)?").upper()
            print("\n")
        
            if customer_request == "Y":
                more_products = True
            else:
                total = 0
                shipping_charge = 10
                
                for i in laptop_sold:
                    total += int(i[3])
                grand_total = total + shipping_charge
                dateandtime = datetime.now()
                x = str(dateandtime).split(" ")
                s = "_".join(x)
                y = s.replace(":","_")

                printsell(name, phone_number, dateandtime, laptop_sold, total, shipping_charge, grand_total)


                billsell(name,y, phone_number, dateandtime, laptop_sold, total, shipping_charge, grand_total)
