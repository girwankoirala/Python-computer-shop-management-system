def printbuy(name, phone_number, dateandtime, laptop_sold, total, shipping_charge, grand_total):
    
            print("-------------------------------------------------------------------------------------------------------------")
            print("-------------------------------------------------------------------------------------------------------------")
            print(" \t \t \t \t \t Thank You For Shopping With Us")
            print("-------------------------------------------------------------------------------------------------------------")
            print("-------------------------------------------------------------------------------------------------------------")
            print ("\n")

            print(" \t \t \t \t\t \tGirwan's Laptop Shop")
            print(" \t\t\t\t\tBirendranagar,08,surkhet,Karnali,nepal\t")
            print("\t\t\t\t\t\t98134434121/938446363545\t\t" )

            print("-------------------------------------------------------------------------------------------------------------")
            print("-------------------------------------------------------------------------------------------------------------")

            print("---- ")
            print(" Bill: \n")
            print("-----")
            print("Customer's Name: "+ str(name))
            print("Contact number: "+ str(phone_number))
            print("Date and time of purchase: "+ str(dateandtime))
            print("-")
            print("\n")
            print("Purchase Details are: ")
            print("-")
            print("Product Name \t \t Total Quantity \t\t Price(per piece) \t\t\t Total")
            print("-")
            for i in laptop_sold:
                print(i[0], "\t\t\t" ,i[1], "\t\t\t " ,i[2], "\t\t\t " ,"$", i[3] )
            print("-")
            print("Your total Bill is : $"+str (total))
            print("Your Shipping charge is : $", shipping_charge)
            print("Grand Total : $"+ str(grand_total))
            print("\n")

def billbuy(name,y,phone_number,dateandtime,laptop_sold,total,shipping_charge, grand_total):
        file= open(str(name)+"_"+str(y)+".txt", "w")
        file.write("-------------------------------------------------------------------------------------------------------------")
        file.write("-------------------------------------------------------------------------------------------------------------")
        file.write(" \t \t \t \t \t Thank You For Shopping With Us!")
        file.write("-------------------------------------------------------------------------------------------------------------")
        file.write("-------------------------------------------------------------------------------------------------------------")
        file.write("\n")

        file.write(" \t \t \t \t\t \tGirwan's Laptop Shop")
        file.write(" \t\t\t\t\tBirendranagar,08,surkhet,Karnali,nepal\t")
        file.write("\t\t\t\t\t\t98134434121/938446363545\t\t" )

        file.write("-------------------------------------------------------------------------------------------------------------")
        file.write("-------------------------------------------------------------------------------------------------------------")



        file.write("\nCustomer's Name: " + str(name))
        file.write("\nContact number: " + str(phone_number))
        file.write("\nDate and time of purchase: " + str(dateandtime))
        file.write("\n" )
        file.write("\n")
        file.write("Purchase Details are: ")
        file.write("\n------------------------------------------------------------------------------------------------------------------------\n" )
        file.write("Product Name \t \t Total Quantity \t\t Price(per piece) \t\t\t Total")
        file.write("\n------------------------------------------------------------------------------------------------------------------------ \n" )


        for i in laptop_sold:
            file.write(str(i[0])+"\t\t\t "+str(i[1])+"\t\t\t\t\t\t "+str(i[2])+"\t\t\t\t\t\t\t"+"$"+str(i[3]) +"\n")


        file.write("-" )
        file.write("\nYour total is : $" + str(total))
        file.write("\nYour Shipping charge is : $ " +""+ str(shipping_charge) +"\n")
        file.write("\nGrand Total : $" + str(grand_total))
        file.write("\n")
        file.close()

def printsell(name, phone_number, dateandtime, laptop_sold, total, shipping_charge, grand_total):
        print("-------------------------------------------------------------------------------------------------------------")
        print("-------------------------------------------------------------------------------------------------------------")
        print(" \t \t \t \t \t Thank You For Shopping With Us!")
        print("-------------------------------------------------------------------------------------------------------------")
        print("-------------------------------------------------------------------------------------------------------------")
        print ("\n")

        print(" \t \t \t \t\t \tGirwan's Laptop Shop")
        print(" \t\t\t\t\tBirendranagar,08,surkhet,Karnali,nepal\t")
        print("\t\t\t\t\t\t98134434121/938446363545\t\t" )

        print("-------------------------------------------------------------------------------------------------------------")
        print("-------------------------------------------------------------------------------------------------------------")

        print("---- ")
        print("Product details: \n")
        print("-----")
        print("Customer's Name: "+ str(name))
        print("Contact number: "+ str(phone_number))
        print("Date and time of purchase: "+ str(dateandtime))
        print("-")
        print("\n")
        print("Sell Details are: ")
        print("-")
        print("Product Name \t \t Total Quantity \t\t Price(per piece) \t\t\t Total")
        print("-")
        for i in laptop_sold:
            print(i[0], "\t\t\t" ,i[1], "\t\t\t " ,i[2], "\t\t\t " ,"$", i[3] )
        print("-")
        print("Your total is : $"+str (total))
        print("Your Shipping charge is : $", shipping_charge)
        print("Grand Total : $"+ str(grand_total))
        print("\n")

def billsell(name,y, phone_number, dateandtime, laptop_sold, total, shipping_charge, grand_total):
        file= open(str(name)+ str(y)+ "file.txt", "w")
        file.write("-------------------------------------------------------------------------------------------------------------")
        file.write("-------------------------------------------------------------------------------------------------------------")
        file.write(" \t \t \t \t \t Thank You For Shopping With Us")
        file.write("-------------------------------------------------------------------------------------------------------------")
        file.write("-------------------------------------------------------------------------------------------------------------")
        file.write("\n")

        file.write(" \t \t \t \t\t \tGirwan's Laptop Shop")
        file.write(" \t\t\t\t\tBirendranagar,08,surkhet,Karnali,nepal\t")
        file.write("\t\t\t\t\t\t98134434121/938446363545\t\t" )

        file.write("-------------------------------------------------------------------------------------------------------------")
        file.write("-------------------------------------------------------------------------------------------------------------")

        file.write("\nCustomer's Name: " + str(name))
        file.write("\nContact number: " + str(phone_number))
        file.write("\nDate and time of purchase: " + str(dateandtime))
        file.write("\n" )
        file.write("\n")
        file.write("Purchase Details are: ")
        file.write("\n------------------------------------------------------------------------------------------------------------------------\n" )
        file.write("Product Name \t \t Total Quantity \t\t Price(per piece) \t\t\t Total")
        file.write("\n------------------------------------------------------------------------------------------------------------------------ \n" )


        for i in laptop_sold:
            file.write(str(i[0])+"\t\t\t "+str(i[1])+"\t\t\t\t\t\t "+str(i[2])+"\t\t\t\t\t\t\t"+"$"+str(i[3]) +"\n")


        file.write("-" )
        file.write("\nYour total is : $" + str(total))
        file.write("\nYour Shipping charge is : $ " +""+ str(shipping_charge) +"\n")
        file.write("\nGrand Total : $" + str(grand_total))
        file.write("\n")
        file.close()

