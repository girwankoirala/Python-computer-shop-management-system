from datetime import datetime
from read import *
from operations import *
from write import *





print("-------------------------------------------------------------------------------------------------------------")
print("-------------------------------------------------------------------------------------------------------------")
print(" \t \t \t \t \t Welcome To Girwan's Laptop Shop!!")
print("-------------------------------------------------------------------------------------------------------------")
print("-------------------------------------------------------------------------------------------------------------")
print ("\n")

print(" \t \t \t \t\t \tGirwan's Laptop Shop")
print(" \t\t\t\t\tBirendranagar,08,surkhet,Karnali,nepal\t")
print("\t\t\t\t\t\t98134434121/938446363545\t\t" )

print("-------------------------------------------------------------------------------------------------------------")
print("-------------------------------------------------------------------------------------------------------------")
print ("\n")



d=filled()


    
loop = True
while loop == True:
    print("**********************************************************************************************************")
    print("1) Sell laptop ")
    print("2) Purchase laptop")
    print("3) Exit")
    print("**********************************************************************************************************")
    print("\n")
    s = False
    while s == False:
        try:
            u_i= int(input("Enter the Choosen option to continue: "))
            s = True
        except:
            print("Please enter the valid input")

    print("\n")

    if u_i == 1:
        
        buyoperate(d)



       

        more_products= False
        

    elif u_i == 2:
        
        
        selloperate(d)



        more_products= False

        print("\n")
        
    elif u_i == 3:
        loop = False
        print("Thank you for visiting our store!")
        print("\n")
    else:
        print("Your option", u_i, "Given input does not match. try again.")
        print("\n")
